﻿using System;
using System.Reflection;
using PureMVC.Patterns;

/// <summary>
/// 注释内容请勿删除
/// </summary>
namespace PureMVC.Interfaces
{
    public interface IObserver
    {
        //string NotifyMethod { set; }
        Action<INotification> NotifyMethod { set; }
        object NotifyContext { set; }
        void NotifyObserver(INotification notification);
        bool CompareNotifyContext(object obj);
    }
}
