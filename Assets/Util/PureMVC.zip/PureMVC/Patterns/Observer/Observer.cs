﻿using System;
using System.Reflection;
using PureMVC.Interfaces;

/// <summary>
/// 注释内容请勿删除
/// </summary>
namespace PureMVC.Patterns
{
    public class Observer : IObserver
    {
        //private string m_notifyMethod;
        private Action<INotification> m_notifyMethod;
        private object m_notifyContext;
        protected readonly object m_syncRoot = new object();
        //public virtual string NotifyMethod
        //{
        //    private get
        //    {
        //        return m_notifyMethod;
        //    }
        //    set
        //    {
        //        m_notifyMethod = value;
        //    }
        //}
        public virtual Action<INotification> NotifyMethod
        {
            private get
            {
                return m_notifyMethod;
            }
            set
            {
                m_notifyMethod = value;
            }
        }
        public virtual object NotifyContext
        {
            private get
            {
                return m_notifyContext;
            }
            set
            {
                m_notifyContext = value;
            }
        }
        //public Observer(string notifyMethod, object notifyContext)
        public Observer(Action<INotification> notifyMethod, object notifyContext)
        {
            m_notifyMethod = notifyMethod;
            m_notifyContext = notifyContext;
        }
        public virtual void NotifyObserver(INotification notification)
        {
            //string method;
            Action<INotification> method;
            object context;
            lock (m_syncRoot)
            {
                method = NotifyMethod;
                context = NotifyContext;
            }
            //Type t = context.GetType();
            //BindingFlags f = BindingFlags.Instance | BindingFlags.Public | BindingFlags.IgnoreCase;
            //MethodInfo mi = t.GetMethod(method, f);
            //mi.Invoke(context, new object[] { notification });
            method.Invoke(notification);
        }
        public virtual bool CompareNotifyContext(object obj)
        {
            lock (m_syncRoot)
            {
                return NotifyContext.Equals(obj);
            }
        }
    }
}
