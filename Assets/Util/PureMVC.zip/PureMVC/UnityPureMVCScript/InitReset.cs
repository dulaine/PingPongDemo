﻿using System;

/// <summary>
/// 初始化和重置接口
/// </summary>
public interface IInitReset
{
    void Init();
    void Reset();
}

/// <summary>
/// 有数据的初始化方法
/// </summary>
public interface IInitResetValud
{
    void Init(params object[] _data);
    void Reset();
}