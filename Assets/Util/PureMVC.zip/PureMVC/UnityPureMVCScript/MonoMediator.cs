﻿using System;
using System.Collections.Generic;
using PureMVC.Interfaces;
using PureMVC.Patterns;
using UnityEngine;

/// <summary>
/// 带有组件管理器的mediator
/// </summary>
public class MonoMediator : Notifier, IMediator, INotifier, IInitReset
{
    protected string mMediatorName = "";
    protected object mViewComponent;
    public GameObject gameObject;           //view对应的obj
    public Transform transform;

    //组件管理数据
    public List<ComponentInitReset> mComInReset = new List<ComponentInitReset>();
    public List<MonoBehaviour> mComMono = new List<MonoBehaviour>();

    public virtual string MediatorName
    {
        get { return mMediatorName; }
    }
    public virtual object ViewComponent
    {
        get { return mViewComponent; }
        set { mViewComponent = value; }
    }
    public MonoMediator(string mediatorName, Transform _viewComponent)
    {
        mMediatorName = mediatorName;
        mViewComponent = _viewComponent;
        gameObject = _viewComponent.gameObject;
        transform = _viewComponent;
    }

    //-------------接口实现---------------
    #region 接口实现
    public virtual IList<string> ListNotificationInterests()
    {
        return new List<string>();
    }
    public virtual void HandleNotification(INotification notification)
    {
    }
    /// <summary>
    /// mediator注册回调
    /// </summary>
    public virtual void OnRegister()
    {
    }
    /// <summary>
    /// mediator删除回调
    /// </summary>
    public virtual void OnRemove()
    {
    }
    /// <summary>
    /// 初始化
    /// </summary>
    public virtual void Init()
    {

    }
    /// <summary>
    /// 重置
    /// </summary>
    public virtual void Reset()
    {

    }
    #endregion

    //-------------公共方法---------------
    #region 公共方法

    #endregion
}
